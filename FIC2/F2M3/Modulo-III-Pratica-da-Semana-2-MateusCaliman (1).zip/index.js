//Importando as bibliotecas
const { Sequelize, Model, DataTypes } =
  require("sequelize");

//Abrindo conexão com o Banco de dados ou criando um novo caso não exista
const sequelize = new Sequelize({
  dialect: "sqlite",
  storage: "empresa.sqlite"
});

// definindo a classe setor
class Setor extends Model {
  static init(sequelize) {
    super.init({
      idsetor: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
      },
      nome: {
        type: DataTypes.STRING(40),
        allowNull: false
      },
      ramal: {
        type: DataTypes.STRING(10),
        allowNull: false
      },
      email: {
        type: DataTypes.STRING(30),
      }
    }, { sequelize, modelname: 'setor', tableName: 'setores' })
  }
}

//inicialização do modelo create table setor
Setor.init(sequelize);

class Funcionario extends Model {
  static init(sequelize) {
    super.init({
      matricula: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
      },
      idsetor: {
        type: DataTypes.INTEGER,
        references: {
          model: Setor,
          key: 'idsetor'}
      },
      nome: {
        type: DataTypes.STRING(60),
        allowNull: false
      },
      nascimento: {
        type: DataTypes.DATE
      },
      telefone: {
        type: DataTypes.STRING(15)
      }
    }, { sequelize, modelName: 'funcionario', tableName: 'funcionarios' })
  }
}

Funcionario.init(sequelize);

(async () => {
  await sequelize.sync({ force: true });
  
  // CREATE - Inserir novos setores
  const setor_create1 = await Setor.create({ nome: "Financeiro", ramal: "2134", email: "financeiro@empresa.com" });
  const setor_create2 = await Setor.create({ nome: "Portaria", ramal: "2136", email: "portaria@empresa.com" });
  const setor_create3 = await Setor.create({ nome: "Contabilidade", ramal: "2137", email: "contabilidade@empresa.com" });
  const setor_create4 = await Setor.create({ nome: "Diretoria", ramal: "2138", email: "diretoria@empresa.com" });
  const setor_create5 = await Setor.create({ nome: "Recursos Humanos", ramal: "2139", email: "rh@empresa.com" });
  const setor_create6 = await Setor.create({ nome: "Secretaria", ramal: "2140", email: "secretaria@empresa.com" });

  // DELETE - Excluir setor Contabilidade
  const setor_delete = await Setor.findOne({ where: { nome: ["Contabilidade"] } });
  if (setor_delete) {
    await setor_delete.destroy();
  }

  // UPDATE - Alterar nome do setor Recursos Humanos para Departamento Pessoal
  const setor_update = await Setor.findOne({ where: { nome: "Recursos Humanos" } });
  if (setor_update) {
    await setor_update.update({ nome: "Departamento Pessoal" });
  }

  // READ - Listar todos os setores
  const setores = await Setor.findAll();
  console.log(setores.map(setor => setor.toJSON()));
})();

