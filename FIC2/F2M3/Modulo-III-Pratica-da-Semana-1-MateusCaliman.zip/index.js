const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('empresa.sqlite', (err) => {
  if (err) {
    return console.error(err.message);
  }
  console.log('Connected to the empresa database.');
});

//db.run("CREATE TABLE aluno(matricula int primary key, id_matricula int not null, nome varchar (60), e_mail varchar(40), cidade varchar(60))");

/*db.run("INSERT INTO ALUNO(matricula, id_matricula,nome,e_mail,cidade)values(1234,1,'Mateus','mateus-caliman@hotmail.com','Vitoria')");
db.run("INSERT INTO ALUNO(matricula, id_matricula,nome,e_mail,cidade)values(1235,1,'Manuel','manuel-caliman@hotmail.com','Vitoria')");
db.run("INSERT INTO ALUNO(matricula, id_matricula,nome,e_mail,cidade)values(1236,1,'Matue','matue-caliman@hotmail.com','Vila Velha')");*/

db.each("SELECT matricula, nome, e_mail, cidade FROM aluno", (err, row) => {
  if (err) {
    console.error(err.message);
  }
  console.log(row.matricula + "\t" + row.nome + "\t" + row.e_mail + "\t" + row.cidade);
});