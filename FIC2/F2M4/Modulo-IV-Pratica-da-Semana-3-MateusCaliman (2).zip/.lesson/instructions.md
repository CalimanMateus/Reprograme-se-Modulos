Olá!

Nessa atividade você vai colocar em prática o conteúdo abordado na 3ª semana do módulo.

ESSA ATIVIDADE  SERÁ DESENVOLVIDA NO REPL.IT E DEVERÁ SER POSTADA SOMENTE OS ARQUIVOS NESTA TAREFA EM ARQUIVO ZIP, CONFORME ORIENTAÇÕES ABAIXO:

Orientações:

_ Assista aos vídeos das aulas da semana.
_ Leia em paralelo os materiais das aulas.
_ Acesse o Replit.
_ Na aplicação da semana, crie a view listar, e cadastrar usuario, suas rotas e seus services para acesso a  API também criada na semana.
_ Atenção. Você deverá utilizar a aplicação da semana e consumir a API criada também na semana.
_ Não será necessário colocar as opções de update e deletar para o usuário.
_ Salve o código no seu computador.
_ Compacte o arquivo.
_ Envie o link do repl.it e o arquivo aqui.

Pessoal a atividade é semelhante ao que fizemos durante as aulas da semana, basta realizar as alterações incluindo as rotas e as views na aplicação, lembre-se de olhar o caminho da sua API e as rotas que irá utilizar.

Se a atividade não estiver sendo mostrada para você, entre em contato com o monitor ou professor mediador o quanto antes.

Bons estudos e boa atividade!

Valor: 8 pontos.