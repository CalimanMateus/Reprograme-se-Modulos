# Instructions  
Olá!

Olá!

Nessa atividade você vai colocar em prática o conteúdo abordado na 1ª semana do módulo.

ESSA ATIVIDADE  SERÁ DESENVOLVIDA NO REPL.IT E DEVERÁ SER POSTADA SOMENTE OS ARQUIVOS NESTA TAREFA EM ARQUIVO ZIP, CONFORME ORIENTAÇÕES ABAIXO:

Orientações:

- Assista aos vídeos das aulas da semana.
- Leia em paralelo os materiais das aulas.
- Acesse o Replit.
- Crie um projeto que retorne a lista de Estados via lista. Aplicação deve conter um formulário para cadastro dos estados na lista e um retorno via json do estado cadastrado.
- Salve o código no seu computador.
- Compacte o arquivo.
- Envie o link do repl.it e o arquivo aqui.

Se a atividade não estiver sendo mostrada para você, entre em contato com o monitor ou professor mediador o quanto antes.

Bons estudos e boa atividade!

Valor: 7 pontos.