const app = require('./app');

app();