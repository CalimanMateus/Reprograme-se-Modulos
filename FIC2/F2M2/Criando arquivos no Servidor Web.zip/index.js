const http = require('http')
const fs = require('fs')
const porta = 443

const servidor = http.createServer((req, res) => {
  fs.appendFile('texte.txt', 'Frase criada pelo appendFile diretamente no arquivo .txt', (err) => {
  if(err)throw err
    console.log('Arquivo criado!')
    res.end()
  })
})

servidor.listen(porta, () => {console.log('Servidor Rodando')})