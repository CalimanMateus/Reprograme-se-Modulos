Atividade Prática da 1ª semana (Repl.it)
Olá!

Nesta atividade você vai colocar em prática o conteúdo abordado na semana.

ESTA ATIVIDADE SERÁ DESENVOLVIDA NO REPL.IT E DEVERÁ SER POSTADA NESTA TAREFA EM ARQUIVO ZIP, CONFORME ORIENTAÇÕES ABAIXO:

Você deve criar um Servidor Web em Node com as seguintes funcionalidades:

Crie uma página (que será lida) em HTML com título e subtítulo.
Adicione CSS à página, mude a cor de fundo e a cor da fonte, pelo menos.
Faça a leitura desse arquivo (HTML).
Crie um arquivo no formato texto (.txt) com conteúdo.
Para definir o conteúdo, acesse o site (https://www.lipsum.com/) e gere o texto ‘aleatório’, copie um parágrafo e cole no arquivo (.txt).
Leia esse arquivo criado (formato .txt) com a ajuda do código: (Codificação) - Como ler arquivo linha a linha no formato texto (.txt))
Siga a estrutura abaixo:

Assista aos vídeos da semana.
Leia, em paralelo, os materiais das aulas da semana.
Acesse o Replit.
Realize a codificação da atividade (Prática da semana 1).
Salve o código no seu computador.
Compacte o arquivo.
Envie o arquivo aqui.
Se a atividade não estiver sendo mostrada para você, entre em contato com o monitor ou professor mediador o quanto antes. 

Valor: 5 pontos

Prazo final: 03/04/2023